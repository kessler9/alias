#!/bin/bash
while true
do
	clear
	nvidia-smi
	sensors
	sleep 2
done
