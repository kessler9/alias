#!/bin/bash
cd /var/lib/docker
BACKUP_FILENAME=volumes_backup_`date +%s`.bak
echo "BACKUP FILENAME: $BACKUP_FILENAME"
tar -cf $BACKUP_FILENAME volumes
cp $BACKUP_FILENAME /media/spin/ && echo "BACKED UP TO 1spin"
/home/admin/source/Dropbox-Uploader/dropbox_uploader.sh upload $BACKUP_FILENAME /
rm -f $BACKUP_FILENAME
