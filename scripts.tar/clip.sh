#!/bin/bash
xsel -b <<< `cat pw`
