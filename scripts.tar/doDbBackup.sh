#!/bin/bash
LOG=~/backup_errors.log
TAR_NAME="pg_backup.`date +%s`.bak"
cd /var/lib/docker/volumes/pgdata/_data &&
tar -cvf $TAR_NAME * 2>>$LOG &&
for device in `ls /media | grep -v cdrom`
do
	cp $TAR_NAME /media/"$device"/ 2>>$LOG
done

[ $? -eq 0 ] && rm -f $TAR_NAME && touch ~/BACKUP_SUCCESS_`date +%s`
