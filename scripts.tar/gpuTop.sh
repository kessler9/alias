#!/bin/bash
watch -n1 nvidia-smi

