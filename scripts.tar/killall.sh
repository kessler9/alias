#!/bin/bash
[ -z $1 ] && echo "You must provide a process name for us to seek and destroy..." && exit 1
ps aux | grep -i "$1" | grep -v grep | awk '{print $2}' | xargs kill -9

