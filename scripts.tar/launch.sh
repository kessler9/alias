#!/bin/bash
transmission-remote -a '$1'
