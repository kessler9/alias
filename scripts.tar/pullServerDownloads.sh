#!/bin/bash
echo "`cat pw`" | pbcopy
if [ -z $2 ]
then
	scp -r admin@vegishare.com:/home/admin/"$1" .
else
	scp -r admin@vegishare.com:/home/admin/"$1" $2
fi
