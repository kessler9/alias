#!/bin/bash
while true
do
	clear
	sensors
	sleep 1
done
