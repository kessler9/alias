#!/bin/bash
ps aux | grep -i gnome | grep -v grep | awk '{print $2}' | xargs kill 
