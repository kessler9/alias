#!/bin/bash
for i in `transmission-remote -l | grep -ivE "ratio|sum" | awk '{print $1}'`
do 
	transmission-remote -t $i -S
done
