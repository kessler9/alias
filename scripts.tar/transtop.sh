#!/bin/bash
while true
do
	clear
	transmission-remote -l
	sleep 1
done
