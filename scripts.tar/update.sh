#!/bin/bash
sudo -S yum clean all <<< `cat pw` &&
sudo yum update &&
sudo yum autoremove
if [ ! -z $1 ]
then
	[[ $1 == "-r" ]] && reboot
	[[ $1 == "-p" ]] && poweroff
fi
